import { User, AuditLogEntry, UserSession } from '../types/auth';
import alexAvatar from '../assets/images/avatar_alex_tech_1791479380661.jpg';
import elenaAvatar from '../assets/images/avatar_elena_design_1791479394832.jpg';
import marcusAvatar from '../assets/images/avatar_marcus_ops_1791479415891.jpg';

export const AVATAR_OPTIONS = [
  { id: 'alex', label: 'Alex (Engineering)', url: alexAvatar },
  { id: 'elena', label: 'Elena (Product Design)', url: elenaAvatar },
  { id: 'marcus', label: 'Marcus (Operations)', url: marcusAvatar },
];

const STORAGE_USERS_KEY = 'authcore_registered_users';
const STORAGE_CURRENT_USER_KEY = 'authcore_current_session';

const INITIAL_USERS: User[] = [
  {
    id: 'user_alex_morgan',
    name: 'Alex Morgan',
    email: 'alex.morgan@worksuite.io',
    password: 'password123!',
    role: 'Principal Staff Engineer',
    department: 'Platform Architecture',
    avatarUrl: alexAvatar,
    bio: 'Distributed systems engineer focused on zero-trust identity frameworks and microservice resilience.',
    location: 'San Francisco, CA',
    joinedAt: 'January 14, 2025',
    lastLoginAt: 'Today at 09:42 AM',
    twoFactorEnabled: true,
    emailNotifications: true,
    sessions: [
      {
        id: 'sess_1',
        device: 'MacBook Pro 16" (macOS 15.2)',
        browser: 'Google Chrome 134.0',
        location: 'San Francisco, US',
        ip: '192.0.2.45',
        isCurrent: true,
        lastActive: 'Active now',
      },
      {
        id: 'sess_2',
        device: 'iPhone 16 Pro (iOS 18.2)',
        browser: 'Mobile Safari',
        location: 'San Francisco, US',
        ip: '198.51.100.12',
        isCurrent: false,
        lastActive: '3 hours ago',
      },
    ],
    activityLog: [
      {
        id: 'log_1',
        event: 'Sign In Successful',
        timestamp: 'Today at 09:42 AM',
        device: 'MacBook Pro 16"',
        ip: '192.0.2.45',
        status: 'success',
      },
      {
        id: 'log_2',
        event: 'Hardware Token Verified',
        timestamp: 'Yesterday at 04:15 PM',
        device: 'MacBook Pro 16"',
        ip: '192.0.2.45',
        status: 'info',
      },
      {
        id: 'log_3',
        event: 'Password Validated',
        timestamp: 'Oct 04, 2026 · 11:30 AM',
        device: 'iPhone 16 Pro',
        ip: '198.51.100.12',
        status: 'success',
      },
    ],
  },
  {
    id: 'user_elena_rostova',
    name: 'Elena Rostova',
    email: 'elena.rostova@designflow.co',
    password: 'password123!',
    role: 'Director of Product Design',
    department: 'Design Systems',
    avatarUrl: elenaAvatar,
    bio: 'Crafting intentional human-centered design systems and digital interfaces for enterprise software.',
    location: 'New York, NY',
    joinedAt: 'February 20, 2025',
    lastLoginAt: 'Yesterday at 06:18 PM',
    twoFactorEnabled: false,
    emailNotifications: true,
    sessions: [
      {
        id: 'sess_3',
        device: 'MacBook Air M3 (macOS 15.1)',
        browser: 'Arc Browser 1.32',
        location: 'New York, US',
        ip: '203.0.113.88',
        isCurrent: true,
        lastActive: 'Active now',
      },
    ],
    activityLog: [
      {
        id: 'log_4',
        event: 'Sign In Successful',
        timestamp: 'Yesterday at 06:18 PM',
        device: 'MacBook Air M3',
        ip: '203.0.113.88',
        status: 'success',
      },
      {
        id: 'log_5',
        event: 'Profile Information Updated',
        timestamp: 'Oct 02, 2026 · 02:20 PM',
        device: 'MacBook Air M3',
        ip: '203.0.113.88',
        status: 'info',
      },
    ],
  },
  {
    id: 'user_marcus_vance',
    name: 'Marcus Vance',
    email: 'marcus.vance@coreops.net',
    password: 'password123!',
    role: 'VP of Global Operations',
    department: 'Business Operations',
    avatarUrl: marcusAvatar,
    bio: 'Scaling organizational infrastructure, compliance protocols, and strategic team performance.',
    location: 'Chicago, IL',
    joinedAt: 'March 05, 2025',
    lastLoginAt: '3 days ago',
    twoFactorEnabled: true,
    emailNotifications: false,
    sessions: [
      {
        id: 'sess_4',
        device: 'Dell XPS 15 (Windows 11)',
        browser: 'Firefox 135.0',
        location: 'Chicago, US',
        ip: '198.51.100.204',
        isCurrent: true,
        lastActive: 'Active now',
      },
    ],
    activityLog: [
      {
        id: 'log_6',
        event: 'Sign In Successful',
        timestamp: 'Oct 05, 2026 · 08:14 AM',
        device: 'Dell XPS 15',
        ip: '198.51.100.204',
        status: 'success',
      },
    ],
  },
];

export function getStoredUsers(): User[] {
  try {
    const raw = localStorage.getItem(STORAGE_USERS_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    const parsed: User[] = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    return parsed;
  } catch {
    return INITIAL_USERS;
  }
}

export function saveStoredUsers(users: User[]): void {
  try {
    localStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Failed to save users in localStorage', err);
  }
}

export function getStoredCurrentUser(): User | null {
  try {
    const raw = localStorage.getItem(STORAGE_CURRENT_USER_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

export function saveStoredCurrentUser(user: User | null): void {
  try {
    if (!user) {
      localStorage.removeItem(STORAGE_CURRENT_USER_KEY);
    } else {
      localStorage.setItem(STORAGE_CURRENT_USER_KEY, JSON.stringify(user));
    }
  } catch (err) {
    console.error('Failed to save current user session', err);
  }
}

export function calculatePasswordStrength(password: string): {
  score: number; // 0 to 4
  label: 'Weak' | 'Fair' | 'Good' | 'Strong';
  hasMinLength: boolean;
  hasUpper: boolean;
  hasLower: boolean;
  hasNumber: boolean;
  hasSpecial: boolean;
} {
  const hasMinLength = password.length >= 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);

  let score = 0;
  if (hasMinLength) score++;
  if (hasUpper && hasLower) score++;
  if (hasNumber) score++;
  if (hasSpecial) score++;

  let label: 'Weak' | 'Fair' | 'Good' | 'Strong' = 'Weak';
  if (score === 2) label = 'Fair';
  else if (score === 3) label = 'Good';
  else if (score === 4) label = 'Strong';

  return {
    score,
    label,
    hasMinLength,
    hasUpper,
    hasLower,
    hasNumber,
    hasSpecial,
  };
}

export function formatCurrentTime(): string {
  const now = new Date();
  return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
