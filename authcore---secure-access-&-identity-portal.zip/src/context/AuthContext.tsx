import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, ToastMessage, AuditLogEntry, UserSession } from '../types/auth';
import {
  getStoredUsers,
  saveStoredUsers,
  getStoredCurrentUser,
  saveStoredCurrentUser,
  formatCurrentTime,
  calculatePasswordStrength,
} from '../utils/authStorage';

interface AuthContextType {
  currentUser: User | null;
  isAuthenticated: boolean;
  allUsers: User[];
  pending2FAUser: User | null;
  toasts: ToastMessage[];
  addToast: (title: string, description?: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  login: (email: string, password: string, rememberMe?: boolean) => { success: boolean; requires2FA?: boolean; message?: string };
  verify2FA: (code: string) => { success: boolean; message?: string };
  cancel2FA: () => void;
  register: (userData: {
    name: string;
    email: string;
    password: string;
    role?: string;
    department?: string;
    avatarUrl?: string;
  }) => { success: boolean; message?: string };
  logout: () => void;
  updateProfile: (updates: Partial<Omit<User, 'id' | 'password' | 'email' | 'sessions' | 'activityLog'>>) => void;
  changePassword: (oldPass: string, newPass: string) => { success: boolean; message?: string };
  toggle2FA: () => void;
  resetPassword: (email: string, newPass: string) => { success: boolean; message?: string };
  terminateSession: (sessionId: string) => void;
  terminateOtherSessions: () => void;
  switchUser: (userId: string) => void;
  deleteAccount: (userId: string) => { success: boolean; message?: string };
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [allUsers, setAllUsers] = useState<User[]>(() => getStoredUsers());
  const [currentUser, setCurrentUser] = useState<User | null>(() => getStoredCurrentUser());
  const [pending2FAUser, setPending2FAUser] = useState<User | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Sync users to storage on state change
  useEffect(() => {
    saveStoredUsers(allUsers);
  }, [allUsers]);

  // Sync current user session
  useEffect(() => {
    saveStoredCurrentUser(currentUser);
  }, [currentUser]);

  const addToast = (title: string, description?: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const login = (email: string, password: string, rememberMe: boolean = false) => {
    const cleanEmail = email.trim().toLowerCase();
    const user = allUsers.find((u) => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      addToast('Sign In Failed', 'No account found with this email address.', 'error');
      return { success: false, message: 'Account not found. Please check your email or register.' };
    }

    if (user.password !== password) {
      addToast('Authentication Error', 'Invalid password. Please check your credentials.', 'error');
      return { success: false, message: 'Incorrect password.' };
    }

    // Check if 2FA is required
    if (user.twoFactorEnabled) {
      setPending2FAUser(user);
      addToast('Two-Factor Verification', 'A security code is required for this account.', 'info');
      return { success: true, requires2FA: true };
    }

    completeLogin(user, rememberMe);
    return { success: true };
  };

  const verify2FA = (code: string) => {
    if (!pending2FAUser) {
      return { success: false, message: 'No pending verification session.' };
    }

    // Accept standard demo codes (e.g., 123456 or any 6 digits for smooth testing)
    const cleanCode = code.trim();
    if (cleanCode.length !== 6 || !/^\d{6}$/.test(cleanCode)) {
      return { success: false, message: 'Security code must be exactly 6 numeric digits.' };
    }

    const user = pending2FAUser;
    setPending2FAUser(null);
    completeLogin(user, user.rememberMe ?? true);
    addToast('Verified', 'Two-factor authentication successful.', 'success');
    return { success: true };
  };

  const cancel2FA = () => {
    setPending2FAUser(null);
  };

  const completeLogin = (user: User, rememberMe: boolean) => {
    const timeStr = `Today at ${formatCurrentTime()}`;
    const newLog: AuditLogEntry = {
      id: `log_${Date.now()}`,
      event: 'Sign In Successful',
      timestamp: timeStr,
      device: navigator.userAgent.includes('Mac') ? 'MacBook Workstation' : 'Desktop Browser',
      ip: '192.0.2.45',
      status: 'success',
    };

    const updatedUser: User = {
      ...user,
      lastLoginAt: timeStr,
      rememberMe,
      activityLog: [newLog, ...(user.activityLog || [])].slice(0, 15),
    };

    setCurrentUser(updatedUser);
    setAllUsers((prev) => prev.map((u) => (u.id === user.id ? updatedUser : u)));
    addToast(`Welcome back, ${user.name}`, `Signed in successfully as ${user.role || 'Member'}.`, 'success');
  };

  const register = (userData: {
    name: string;
    email: string;
    password: string;
    role?: string;
    department?: string;
    avatarUrl?: string;
  }) => {
    const cleanEmail = userData.email.trim().toLowerCase();
    const existing = allUsers.find((u) => u.email.toLowerCase() === cleanEmail);

    if (existing) {
      addToast('Registration Blocked', 'An account with this email address already exists.', 'error');
      return { success: false, message: 'Email already registered. Try signing in instead.' };
    }

    const strength = calculatePasswordStrength(userData.password);
    if (!strength.hasMinLength || strength.score < 2) {
      addToast('Weak Password', 'Password must be at least 8 characters with mixed characters.', 'error');
      return { success: false, message: 'Password does not meet minimum security requirements.' };
    }

    const now = new Date();
    const joinedAt = now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    const timeStr = `Today at ${formatCurrentTime()}`;

    const newId = `user_${Date.now()}`;
    const initialSession: UserSession = {
      id: `sess_${Date.now()}`,
      device: navigator.userAgent.includes('Mac') ? 'MacBook Pro (macOS)' : 'Desktop Browser',
      browser: 'Web Session',
      location: 'Local Session',
      ip: '192.0.2.1',
      isCurrent: true,
      lastActive: 'Active now',
    };

    const initialLog: AuditLogEntry = {
      id: `log_${Date.now()}`,
      event: 'Account Registered & Activated',
      timestamp: timeStr,
      device: initialSession.device,
      ip: initialSession.ip,
      status: 'success',
    };

    const newUser: User = {
      id: newId,
      name: userData.name.trim(),
      email: cleanEmail,
      password: userData.password,
      role: userData.role?.trim() || 'Software Engineer',
      department: userData.department?.trim() || 'Engineering',
      avatarUrl: userData.avatarUrl || '',
      bio: 'New team member on AuthCore platform.',
      location: 'Remote',
      joinedAt,
      lastLoginAt: timeStr,
      twoFactorEnabled: false,
      rememberMe: true,
      emailNotifications: true,
      sessions: [initialSession],
      activityLog: [initialLog],
    };

    const updatedList = [...allUsers, newUser];
    setAllUsers(updatedList);
    setCurrentUser(newUser);

    addToast('Account Created', `Welcome to AuthCore, ${newUser.name}!`, 'success');
    return { success: true };
  };

  const logout = () => {
    if (currentUser) {
      addToast('Signed Out', 'Your session has ended securely.', 'info');
    }
    setCurrentUser(null);
    setPending2FAUser(null);
  };

  const updateProfile = (updates: Partial<Omit<User, 'id' | 'password' | 'email' | 'sessions' | 'activityLog'>>) => {
    if (!currentUser) return;

    const timeStr = `Today at ${formatCurrentTime()}`;
    const newLog: AuditLogEntry = {
      id: `log_${Date.now()}`,
      event: 'Profile Settings Updated',
      timestamp: timeStr,
      device: 'Current Session',
      ip: '192.0.2.45',
      status: 'info',
    };

    const updatedUser: User = {
      ...currentUser,
      ...updates,
      activityLog: [newLog, ...(currentUser.activityLog || [])].slice(0, 15),
    };

    setCurrentUser(updatedUser);
    setAllUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
    addToast('Profile Updated', 'Your profile details were saved successfully.', 'success');
  };

  const changePassword = (oldPass: string, newPass: string) => {
    if (!currentUser) {
      return { success: false, message: 'You must be logged in to update your password.' };
    }

    if (currentUser.password !== oldPass) {
      addToast('Verification Failed', 'Current password is incorrect.', 'error');
      return { success: false, message: 'Current password does not match.' };
    }

    const strength = calculatePasswordStrength(newPass);
    if (!strength.hasMinLength || strength.score < 2) {
      addToast('Password Too Weak', 'New password must have at least 8 characters.', 'error');
      return { success: false, message: 'New password does not meet security standards.' };
    }

    const timeStr = `Today at ${formatCurrentTime()}`;
    const newLog: AuditLogEntry = {
      id: `log_${Date.now()}`,
      event: 'Password Changed Successfully',
      timestamp: timeStr,
      device: 'Current Session',
      ip: '192.0.2.45',
      status: 'warning',
    };

    const updatedUser: User = {
      ...currentUser,
      password: newPass,
      activityLog: [newLog, ...(currentUser.activityLog || [])].slice(0, 15),
    };

    setCurrentUser(updatedUser);
    setAllUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
    addToast('Security Updated', 'Your account password has been updated.', 'success');
    return { success: true };
  };

  const toggle2FA = () => {
    if (!currentUser) return;

    const nextState = !currentUser.twoFactorEnabled;
    const timeStr = `Today at ${formatCurrentTime()}`;
    const newLog: AuditLogEntry = {
      id: `log_${Date.now()}`,
      event: nextState ? 'Two-Factor Authentication Enabled' : 'Two-Factor Authentication Disabled',
      timestamp: timeStr,
      device: 'Current Session',
      ip: '192.0.2.45',
      status: nextState ? 'success' : 'warning',
    };

    const updatedUser: User = {
      ...currentUser,
      twoFactorEnabled: nextState,
      activityLog: [newLog, ...(currentUser.activityLog || [])].slice(0, 15),
    };

    setCurrentUser(updatedUser);
    setAllUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
    addToast(
      nextState ? '2FA Protection Activated' : '2FA Protection Deactivated',
      nextState ? 'Future logins will require two-factor confirmation.' : 'Two-factor verification turned off.',
      nextState ? 'success' : 'info'
    );
  };

  const resetPassword = (email: string, newPass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const user = allUsers.find((u) => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      return { success: false, message: 'No user registered with this email address.' };
    }

    const strength = calculatePasswordStrength(newPass);
    if (!strength.hasMinLength || strength.score < 2) {
      return { success: false, message: 'New password must have at least 8 characters.' };
    }

    const timeStr = `Today at ${formatCurrentTime()}`;
    const newLog: AuditLogEntry = {
      id: `log_${Date.now()}`,
      event: 'Password Recovered via Reset Flow',
      timestamp: timeStr,
      device: 'Recovery Session',
      ip: '192.0.2.1',
      status: 'warning',
    };

    const updatedUser: User = {
      ...user,
      password: newPass,
      activityLog: [newLog, ...(user.activityLog || [])].slice(0, 15),
    };

    setAllUsers((prev) => prev.map((u) => (u.id === user.id ? updatedUser : u)));
    if (currentUser?.id === user.id) {
      setCurrentUser(updatedUser);
    }

    addToast('Password Reset Complete', 'You can now log in with your new password.', 'success');
    return { success: true };
  };

  const terminateSession = (sessionId: string) => {
    if (!currentUser) return;

    const remainingSessions = currentUser.sessions.filter((s) => s.id !== sessionId);
    const updatedUser: User = {
      ...currentUser,
      sessions: remainingSessions,
    };

    setCurrentUser(updatedUser);
    setAllUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
    addToast('Session Revoked', 'The selected device has been logged out.', 'info');
  };

  const terminateOtherSessions = () => {
    if (!currentUser) return;

    const currentSessionsOnly = currentUser.sessions.filter((s) => s.isCurrent);
    const updatedUser: User = {
      ...currentUser,
      sessions: currentSessionsOnly,
    };

    setCurrentUser(updatedUser);
    setAllUsers((prev) => prev.map((u) => (u.id === currentUser.id ? updatedUser : u)));
    addToast('Other Devices Disconnected', 'All remote device sessions have been terminated.', 'success');
  };

  const switchUser = (userId: string) => {
    const target = allUsers.find((u) => u.id === userId);
    if (target) {
      setCurrentUser(target);
      addToast('Account Switched', `Now viewing as ${target.name}.`, 'info');
    }
  };

  const deleteAccount = (userId: string) => {
    if (allUsers.length <= 1) {
      return { success: false, message: 'Cannot delete the only remaining account.' };
    }

    const filtered = allUsers.filter((u) => u.id !== userId);
    setAllUsers(filtered);

    if (currentUser?.id === userId) {
      setCurrentUser(null);
      addToast('Account Removed', 'The account has been deleted.', 'info');
    } else {
      addToast('Account Removed', 'User profile deleted from local repository.', 'info');
    }

    return { success: true };
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        allUsers,
        pending2FAUser,
        toasts,
        addToast,
        removeToast,
        login,
        verify2FA,
        cancel2FA,
        register,
        logout,
        updateProfile,
        changePassword,
        toggle2FA,
        resetPassword,
        terminateSession,
        terminateOtherSessions,
        switchUser,
        deleteAccount,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
