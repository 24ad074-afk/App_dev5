import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { AVATAR_OPTIONS } from '../../utils/authStorage';
import { Check, User as UserIcon, Mail, Briefcase, MapPin, Building, Save } from 'lucide-react';

export const ProfileTab: React.FC = () => {
  const { currentUser, updateProfile } = useAuth();

  const [name, setName] = useState(currentUser?.name || '');
  const [role, setRole] = useState(currentUser?.role || '');
  const [department, setDepartment] = useState(currentUser?.department || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [location, setLocation] = useState(currentUser?.location || '');
  const [avatarUrl, setAvatarUrl] = useState(currentUser?.avatarUrl || AVATAR_OPTIONS[0].url);
  const [emailNotifications, setEmailNotifications] = useState(currentUser?.emailNotifications ?? true);
  const [isSaved, setIsSaved] = useState(false);

  if (!currentUser) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name,
      role,
      department,
      bio,
      location,
      avatarUrl,
      emailNotifications,
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">Profile & Identity</h2>
        <p className="text-xs text-slate-400 mt-1">
          Manage your organization profile information, public directory details, and notification preferences.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Avatar Selection Card */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-xs font-semibold text-white uppercase tracking-wider">Profile Photo</h3>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <img
              src={avatarUrl}
              alt="Current avatar preview"
              className="w-16 h-16 rounded-xl object-cover border border-slate-700 shrink-0"
              referrerPolicy="no-referrer"
            />
            <div className="space-y-2">
              <span className="text-xs text-slate-300 block font-medium">Choose an Avatar Portrait</span>
              <div className="flex items-center gap-3">
                {AVATAR_OPTIONS.map((opt) => {
                  const isSelected = avatarUrl === opt.url;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setAvatarUrl(opt.url)}
                      className={`relative p-0.5 rounded-lg border transition-all ${
                        isSelected
                          ? 'border-indigo-500 ring-2 ring-indigo-500/30'
                          : 'border-slate-800 hover:border-slate-700 opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img
                        src={opt.url}
                        alt={opt.label}
                        className="w-12 h-12 rounded-md object-cover"
                        referrerPolicy="no-referrer"
                      />
                      {isSelected && (
                        <div className="absolute -top-1 -right-1 w-4 h-4 bg-indigo-600 rounded-full flex items-center justify-center text-white">
                          <Check className="w-2.5 h-2.5" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* General Information Card */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
          <h3 className="text-xs font-semibold text-white uppercase tracking-wider">Account Details</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="prof-name" className="block text-xs font-medium text-slate-300 mb-1.5">
                Full Legal Name
              </label>
              <div className="relative">
                <input
                  id="prof-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
                <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label htmlFor="prof-email" className="block text-xs font-medium text-slate-300 mb-1.5">
                Primary Account Email (Immutable)
              </label>
              <div className="relative">
                <input
                  id="prof-email"
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950/60 border border-slate-800/60 rounded-lg text-slate-400 cursor-not-allowed"
                />
                <Mail className="w-4 h-4 text-slate-600 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label htmlFor="prof-role" className="block text-xs font-medium text-slate-300 mb-1.5">
                Job Title
              </label>
              <div className="relative">
                <input
                  id="prof-role"
                  type="text"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
                <Briefcase className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label htmlFor="prof-dept" className="block text-xs font-medium text-slate-300 mb-1.5">
                Department
              </label>
              <div className="relative">
                <input
                  id="prof-dept"
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  required
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
                <Building className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            <div>
              <label htmlFor="prof-loc" className="block text-xs font-medium text-slate-300 mb-1.5">
                Work Location / Timezone
              </label>
              <div className="relative">
                <input
                  id="prof-loc"
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
                <MapPin className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          </div>

          <div>
            <label htmlFor="prof-bio" className="block text-xs font-medium text-slate-300 mb-1.5">
              Biography & Responsibilities
            </label>
            <textarea
              id="prof-bio"
              rows={3}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full p-3 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors resize-none leading-relaxed"
            />
          </div>
        </div>

        {/* Notification preferences */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
          <h3 className="text-xs font-semibold text-white uppercase tracking-wider">Security Notifications</h3>
          <label className="flex items-start gap-3 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={emailNotifications}
              onChange={(e) => setEmailNotifications(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded border-slate-700 bg-slate-950 text-indigo-600 focus:ring-indigo-500 focus:ring-offset-slate-900 accent-indigo-600 cursor-pointer"
            />
            <div>
              <span className="text-xs font-medium text-slate-200 block">Security Alert Dispatches</span>
              <span className="text-xs text-slate-400 leading-relaxed block">
                Receive instant emails when a login from an unrecognized device or unusual IP address occurs.
              </span>
            </div>
          </label>
        </div>

        {/* Save button */}
        <div className="flex items-center justify-end gap-3 pt-2">
          {isSaved && (
            <span className="text-xs text-emerald-400 font-medium flex items-center gap-1.5 animate-in fade-in">
              <Check className="w-3.5 h-3.5" /> Changes saved successfully
            </span>
          )}
          <button
            type="submit"
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-sm"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Profile</span>
          </button>
        </div>
      </form>
    </div>
  );
};
