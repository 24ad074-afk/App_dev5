import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Laptop, Smartphone, Monitor, ShieldCheck, Trash2, LogOut } from 'lucide-react';

export const SessionsTab: React.FC = () => {
  const { currentUser, terminateSession, terminateOtherSessions } = useAuth();

  if (!currentUser) return null;

  const getDeviceIcon = (deviceName: string) => {
    const lower = deviceName.toLowerCase();
    if (lower.includes('iphone') || lower.includes('android') || lower.includes('mobile')) {
      return <Smartphone className="w-4 h-4 text-slate-400" />;
    }
    if (lower.includes('macbook') || lower.includes('dell') || lower.includes('laptop')) {
      return <Laptop className="w-4 h-4 text-slate-400" />;
    }
    return <Monitor className="w-4 h-4 text-slate-400" />;
  };

  const otherSessions = currentUser.sessions?.filter((s) => !s.isCurrent) || [];

  return (
    <div className="max-w-4xl space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Authorized Active Sessions</h2>
          <p className="text-xs text-slate-400 mt-1">
            Devices that currently have persistent tokens or active browser credentials for this account.
          </p>
        </div>

        {otherSessions.length > 0 && (
          <button
            onClick={terminateOtherSessions}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-rose-300 hover:text-white bg-rose-950/40 hover:bg-rose-900/60 border border-rose-900/60 rounded-lg transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out Other Devices</span>
          </button>
        )}
      </div>

      {/* Current Session */}
      <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-white uppercase tracking-wider">Current Session</span>
          <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5" /> Active in this browser
          </span>
        </div>

        {currentUser.sessions?.filter((s) => s.isCurrent).map((session) => (
          <div key={session.id} className="flex items-start sm:items-center justify-between gap-4 p-3 bg-slate-950 rounded-lg border border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded bg-slate-900 text-slate-300">
                {getDeviceIcon(session.device)}
              </div>
              <div>
                <div className="text-xs font-semibold text-white">{session.device}</div>
                <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                  <span>{session.browser}</span>
                  <span aria-hidden="true">·</span>
                  <span>{session.location}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">{session.ip}</span>
                </div>
              </div>
            </div>
            <span className="text-xs text-slate-500 font-mono tabular-nums shrink-0">
              {session.lastActive}
            </span>
          </div>
        ))}
      </div>

      {/* Other Sessions */}
      <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
        <h3 className="text-xs font-semibold text-white uppercase tracking-wider">Other Authorized Devices</h3>

        {otherSessions.length > 0 ? (
          <div className="space-y-2.5">
            {otherSessions.map((session) => (
              <div
                key={session.id}
                className="flex items-center justify-between gap-4 p-3 bg-slate-950 rounded-lg border border-slate-800/80"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded bg-slate-900 text-slate-400">
                    {getDeviceIcon(session.device)}
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-200">{session.device}</div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span>{session.browser}</span>
                      <span aria-hidden="true">·</span>
                      <span>{session.location}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono tabular-nums">{session.ip}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <span className="hidden sm:inline text-xs text-slate-500 font-mono tabular-nums">
                    {session.lastActive}
                  </span>
                  <button
                    onClick={() => terminateSession(session.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 rounded hover:bg-slate-900 transition-colors"
                    title="Revoke device access"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-500 py-3">
            No other devices are currently authorized. Only this active workstation session exists.
          </p>
        )}
      </div>
    </div>
  );
};
