import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Search, UserCheck, ShieldCheck, ArrowRightLeft, Trash2, UserPlus } from 'lucide-react';

interface DirectoryTabProps {
  onRegisterAnother: () => void;
}

export const DirectoryTab: React.FC<DirectoryTabProps> = ({ onRegisterAnother }) => {
  const { allUsers, currentUser, switchUser, deleteAccount } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');

  const filteredUsers = allUsers.filter((u) => {
    const matchesSearch =
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.role.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDept = departmentFilter === 'all' || u.department.toLowerCase() === departmentFilter.toLowerCase();
    return matchesSearch && matchesDept;
  });

  const departments = Array.from(new Set(allUsers.map((u) => u.department)));

  return (
    <div className="max-w-5xl space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Organization Directory</h2>
          <p className="text-xs text-slate-400 mt-1">
            Accounts registered in this local environment. Switch identities or register additional test profiles.
          </p>
        </div>

        <button
          onClick={onRegisterAnother}
          className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-xs"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>Register New Account</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by name, email, or role..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition-colors"
          />
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg w-full sm:w-auto overflow-x-auto">
          <button
            onClick={() => setDepartmentFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
              departmentFilter === 'all'
                ? 'bg-slate-800 text-white'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            All Departments
          </button>
          {departments.map((dept) => (
            <button
              key={dept}
              onClick={() => setDepartmentFilter(dept)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
                departmentFilter.toLowerCase() === dept.toLowerCase()
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {dept}
            </button>
          ))}
        </div>
      </div>

      {/* Directory Table */}
      <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800 uppercase tracking-wider font-semibold text-[10px]">
              <tr>
                <th className="px-5 py-3">Member</th>
                <th className="px-5 py-3">Department & Role</th>
                <th className="px-5 py-3 text-right">Registered</th>
                <th className="px-5 py-3 text-right">Security</th>
                <th className="px-5 py-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredUsers.length > 0 ? (
                filteredUsers.map((user) => {
                  const isCurrent = currentUser?.id === user.id;
                  return (
                    <tr
                      key={user.id}
                      className={`hover:bg-slate-800/40 transition-colors ${
                        isCurrent ? 'bg-indigo-950/15' : ''
                      }`}
                    >
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={user.avatarUrl}
                            alt={user.name}
                            className="w-9 h-9 rounded-md object-cover border border-slate-800 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <div className="font-semibold text-slate-100 flex items-center gap-2">
                              <span>{user.name}</span>
                              {isCurrent && (
                                <span className="text-[10px] text-indigo-400 font-mono font-medium">
                                  (Active You)
                                </span>
                              )}
                            </div>
                            <div className="text-slate-400 text-[11px]">{user.email}</div>
                          </div>
                        </div>
                      </td>

                      <td className="px-5 py-3.5">
                        <div className="font-medium text-slate-200">{user.role}</div>
                        <div className="text-slate-400 text-[11px]">{user.department}</div>
                      </td>

                      <td className="px-5 py-3.5 text-right font-mono tabular-nums text-slate-400">
                        {user.joinedAt}
                      </td>

                      <td className="px-5 py-3.5 text-right">
                        {user.twoFactorEnabled ? (
                          <span className="text-emerald-400 font-medium inline-flex items-center gap-1">
                            <ShieldCheck className="w-3.5 h-3.5" /> 2FA Active
                          </span>
                        ) : (
                          <span className="text-slate-500 font-normal">Password Only</span>
                        )}
                      </td>

                      <td className="px-5 py-3.5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {!isCurrent ? (
                            <>
                              <button
                                onClick={() => switchUser(user.id)}
                                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded transition-colors"
                                title="Switch session to this user"
                              >
                                <ArrowRightLeft className="w-3.5 h-3.5" />
                                <span>Switch</span>
                              </button>
                              <button
                                onClick={() => deleteAccount(user.id)}
                                className="p-1 text-slate-500 hover:text-rose-400 rounded hover:bg-slate-800 transition-colors"
                                title="Delete user"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          ) : (
                            <span className="text-xs text-indigo-400 font-medium">Current Session</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={5} className="px-5 py-8 text-center text-slate-500">
                    No accounts match the selected filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
