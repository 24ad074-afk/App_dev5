import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { PasswordStrengthMeter } from '../auth/PasswordStrengthMeter';
import { ShieldCheck, ShieldAlert, KeyRound, Lock, Eye, EyeOff, Check, QrCode, Copy } from 'lucide-react';

export const SecurityTab: React.FC = () => {
  const { currentUser, changePassword, toggle2FA, addToast } = useAuth();

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [copiedKey, setCopiedKey] = useState(false);

  if (!currentUser) return null;

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (newPassword !== confirmPassword) {
      setError('New passwords do not match.');
      return;
    }

    const res = changePassword(currentPassword, newPassword);
    if (res.success) {
      setSuccess('Your password has been securely changed.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } else {
      setError(res.message || 'Failed to update password.');
    }
  };

  const copySecretKey = () => {
    navigator.clipboard?.writeText('JBSWY3DPEHPK3PXP');
    setCopiedKey(true);
    addToast('Copied to Clipboard', 'TOTP Secret Key copied.', 'info');
    setTimeout(() => setCopiedKey(false), 2000);
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">Security & Credentials</h2>
        <p className="text-xs text-slate-400 mt-1">
          Enforce authentication standards, update access keys, and configure hardware/software multi-factor verification.
        </p>
      </div>

      {/* Two-Factor Authentication Toggle Card */}
      <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className={`p-2.5 rounded-lg border shrink-0 ${
              currentUser.twoFactorEnabled
                ? 'bg-emerald-950/40 border-emerald-800/60 text-emerald-400'
                : 'bg-amber-950/40 border-amber-800/60 text-amber-400'
            }`}>
              {currentUser.twoFactorEnabled ? (
                <ShieldCheck className="w-5 h-5" />
              ) : (
                <ShieldAlert className="w-5 h-5" />
              )}
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Two-Factor Authentication (2FA)</h3>
              <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
                Add an extra layer of protection by requiring a 6-digit authenticator code upon signing in.
              </p>
            </div>
          </div>

          <button
            onClick={toggle2FA}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors shrink-0 ${
              currentUser.twoFactorEnabled
                ? 'bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/60'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm'
            }`}
          >
            {currentUser.twoFactorEnabled ? 'Disable 2FA' : 'Enable 2FA Protection'}
          </button>
        </div>

        {/* Setup Details Box if 2FA is active */}
        {currentUser.twoFactorEnabled && (
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800/80 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-200">TOTP Authenticator Configured</span>
              <span className="text-[11px] text-emerald-400 font-medium flex items-center gap-1">
                <Check className="w-3 h-3" /> Active on this account
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Compatible with Google Authenticator, 1Password, Bitwarden, or Authy.
            </p>
            <div className="flex items-center justify-between p-2.5 rounded bg-slate-900 border border-slate-800">
              <div className="min-w-0">
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-medium">Backup Secret Key</span>
                <span className="font-mono text-xs text-indigo-300 tracking-wider">JBSWY3DPEHPK3PXP</span>
              </div>
              <button
                type="button"
                onClick={copySecretKey}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 rounded transition-colors"
              >
                {copiedKey ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Change Password Form */}
      <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-indigo-400" />
          <h3 className="text-sm font-semibold text-white">Change Account Password</h3>
        </div>
        <p className="text-xs text-slate-400">
          Ensure your password contains at least 8 characters, combining uppercase letters, numbers, and symbols.
        </p>

        {error && (
          <div className="p-3 text-xs text-rose-300 bg-rose-950/40 border border-rose-900/60 rounded-lg">
            {error}
          </div>
        )}
        {success && (
          <div className="p-3 text-xs text-emerald-300 bg-emerald-950/40 border border-emerald-900/60 rounded-lg">
            {success}
          </div>
        )}

        <form onSubmit={handlePasswordSubmit} className="space-y-4">
          <div>
            <label htmlFor="old-pass" className="block text-xs font-medium text-slate-300 mb-1.5">
              Current Password
            </label>
            <div className="relative">
              <input
                id="old-pass"
                type={showPassword ? 'text' : 'password'}
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                required
                className="w-full pl-9 pr-10 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
              />
              <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="chg-new-pass" className="block text-xs font-medium text-slate-300 mb-1.5">
                New Password
              </label>
              <div className="relative">
                <input
                  id="chg-new-pass"
                  type={showPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  className="w-full pl-9 pr-10 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <PasswordStrengthMeter password={newPassword} />
            </div>

            <div>
              <label htmlFor="chg-confirm-pass" className="block text-xs font-medium text-slate-300 mb-1.5">
                Confirm New Password
              </label>
              <div className="relative">
                <input
                  id="chg-confirm-pass"
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="w-full pl-9 pr-10 py-2 text-xs bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-sm"
            >
              Update Password
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
