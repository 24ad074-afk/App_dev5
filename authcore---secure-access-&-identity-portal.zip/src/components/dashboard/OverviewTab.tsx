import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { DashboardTab } from '../../types/auth';
import { ShieldCheck, ShieldAlert, Monitor, Key, UserCheck, Clock, MapPin, ArrowUpRight } from 'lucide-react';

interface OverviewTabProps {
  onNavigateTab: (tab: DashboardTab) => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({ onNavigateTab }) => {
  const { currentUser } = useAuth();

  if (!currentUser) return null;

  return (
    <div className="space-y-6">
      {/* Account Hero Banner */}
      <div className="p-6 rounded-xl bg-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-start sm:items-center gap-4">
          <img
            src={currentUser.avatarUrl}
            alt={currentUser.name}
            className="w-16 h-16 rounded-xl object-cover border border-slate-700/80 shrink-0"
            referrerPolicy="no-referrer"
          />
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-white tracking-tight">{currentUser.name}</h2>
              {currentUser.twoFactorEnabled && (
                <span title="2FA Verified Protection" className="inline-flex">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                </span>
              )}
            </div>

            {/* Zero-Pill unboxed metadata with subtle typographic separators */}
            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-400 mt-1">
              <span>{currentUser.role}</span>
              <span aria-hidden="true">·</span>
              <span>{currentUser.department}</span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-500" />
                {currentUser.location}
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400 mt-2 font-mono tabular-nums">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              <span>Last authenticated {currentUser.lastLoginAt}</span>
              <span aria-hidden="true">·</span>
              <span>Member since {currentUser.joinedAt}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <button
            onClick={() => onNavigateTab('profile')}
            className="flex-1 md:flex-none px-3.5 py-2 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700/60"
          >
            Edit Profile
          </button>
          <button
            onClick={() => onNavigateTab('security')}
            className="flex-1 md:flex-none px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors shadow-xs"
          >
            Security Center
          </button>
        </div>
      </div>

      {/* Metric Cards - Clean single-elevation depth */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Card 1: 2FA State */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Two-Factor Authentication</span>
            {currentUser.twoFactorEnabled ? (
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            ) : (
              <ShieldAlert className="w-4 h-4 text-amber-400" />
            )}
          </div>
          <div>
            <div className="text-lg font-semibold text-white">
              {currentUser.twoFactorEnabled ? 'Active & Enforced' : 'Not Configured'}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {currentUser.twoFactorEnabled
                ? 'Time-based OTP token verification active on sign in.'
                : 'Account is protected by standard password only.'}
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('security')}
            className="mt-3 text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 self-start"
          >
            <span>{currentUser.twoFactorEnabled ? 'Manage 2FA' : 'Enable 2FA'}</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        {/* Card 2: Active Sessions */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Active Authorized Devices</span>
            <Monitor className="w-4 h-4 text-slate-400" />
          </div>
          <div>
            <div className="text-lg font-semibold text-white font-mono tabular-nums">
              {currentUser.sessions?.length || 1} Device{currentUser.sessions?.length === 1 ? '' : 's'}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Currently connected across desktop and mobile workstations.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('sessions')}
            className="mt-3 text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 self-start"
          >
            <span>Review sessions</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>

        {/* Card 3: Account Verification */}
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-medium">Identity Status</span>
            <UserCheck className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <div className="text-lg font-semibold text-white">Enterprise Verified</div>
            <p className="text-xs text-slate-400 mt-1">
              Email domain and directory permissions validated.
            </p>
          </div>
          <button
            onClick={() => onNavigateTab('directory')}
            className="mt-3 text-xs text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 self-start"
          >
            <span>View team directory</span>
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Security Audit Activity Log Table */}
      <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white">Recent Security Activity</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Historical access log, credential validation, and device sign-ins.
            </p>
          </div>
          <span className="text-xs text-slate-500 font-mono tabular-nums">
            {currentUser.activityLog?.length || 0} events recorded
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800/80 uppercase tracking-wider font-semibold text-[10px]">
              <tr>
                <th className="px-5 py-3">Event</th>
                <th className="px-5 py-3">Device & Client</th>
                <th className="px-5 py-3 text-right">IP Address</th>
                <th className="px-5 py-3 text-right">Timestamp</th>
                <th className="px-5 py-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {currentUser.activityLog && currentUser.activityLog.length > 0 ? (
                currentUser.activityLog.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="px-5 py-3 font-medium text-slate-200">{log.event}</td>
                    <td className="px-5 py-3 text-slate-400">{log.device}</td>
                    <td className="px-5 py-3 text-right font-mono tabular-nums text-slate-400">{log.ip}</td>
                    <td className="px-5 py-3 text-right font-mono tabular-nums text-slate-400">{log.timestamp}</td>
                    <td className="px-5 py-3 text-right">
                      {log.status === 'success' && (
                        <span className="text-emerald-400 font-medium">Success</span>
                      )}
                      {log.status === 'warning' && (
                        <span className="text-amber-400 font-medium">Modified</span>
                      )}
                      {log.status === 'info' && (
                        <span className="text-indigo-400 font-medium">Info</span>
                      )}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-5 py-6 text-center text-slate-500">
                    No recent activity records available.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
