import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { PasswordStrengthMeter } from './PasswordStrengthMeter';
import { X, KeyRound, CheckCircle2, ArrowLeft, Eye, EyeOff } from 'lucide-react';

interface ForgotPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialEmail?: string;
}

export const ForgotPasswordModal: React.FC<ForgotPasswordModalProps> = ({ isOpen, onClose, initialEmail = '' }) => {
  const { allUsers, resetPassword, addToast } = useAuth();
  const [step, setStep] = useState<'email' | 'code' | 'new-password' | 'success'>('email');
  const [email, setEmail] = useState(initialEmail);
  const [code, setCode] = useState('');
  const [generatedDemoCode, setGeneratedDemoCode] = useState('849201');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleRequestCode = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const clean = email.trim().toLowerCase();
    if (!clean) {
      setError('Please provide your account email address.');
      return;
    }

    const userExists = allUsers.some((u) => u.email.toLowerCase() === clean);
    if (!userExists) {
      setError('No registered account was found with this email address.');
      return;
    }

    // Generate random 6-digit code for simulation
    const simulatedCode = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedDemoCode(simulatedCode);
    setStep('code');
    addToast('Security Code Sent', `A verification code was dispatched to ${clean}.`, 'info');
  };

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (code.trim() !== generatedDemoCode && code.trim() !== '123456') {
      setError('Invalid security code. Please check the code provided.');
      return;
    }
    setStep('new-password');
  };

  const handleSetNewPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (newPassword.length < 8) {
      setError('Password must contain at least 8 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match. Please re-enter.');
      return;
    }

    const res = resetPassword(email, newPassword);
    if (res.success) {
      setStep('success');
    } else {
      setError(res.message || 'Failed to update password.');
    }
  };

  const handleResetComplete = () => {
    onClose();
    setStep('email');
    setEmail('');
    setCode('');
    setNewPassword('');
    setConfirmPassword('');
    setError(null);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="forgot-password-title"
    >
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-6 text-slate-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-500 hover:text-slate-300 p-1 rounded-md transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-slate-400"
          aria-label="Close dialog"
        >
          <X className="w-4 h-4" />
        </button>

        {step === 'email' && (
          <form onSubmit={handleRequestCode} className="space-y-4">
            <div className="flex items-center gap-2.5 text-indigo-400 mb-1">
              <KeyRound className="w-5 h-5" />
              <h3 id="forgot-password-title" className="text-base font-semibold text-white tracking-tight">
                Reset Password
              </h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Enter your registered work email to receive a secure recovery code.
            </p>

            {error && (
              <div className="p-3 text-xs text-rose-300 bg-rose-950/40 border border-rose-900/50 rounded-lg">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="reset-email" className="block text-xs font-medium text-slate-300 mb-1.5">
                Work Email Address
              </label>
              <input
                id="reset-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@company.com"
                required
                className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors rounded-lg"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors rounded-lg shadow-sm"
              >
                Send Recovery Code
              </button>
            </div>
          </form>
        )}

        {step === 'code' && (
          <form onSubmit={handleVerifyCode} className="space-y-4">
            <div className="flex items-center gap-2 text-slate-300 mb-1">
              <button
                type="button"
                onClick={() => setStep('email')}
                className="text-slate-400 hover:text-white p-1 rounded"
                aria-label="Back to email step"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
              <h3 className="text-base font-semibold text-white tracking-tight">Enter Verification Code</h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              We sent a 6-digit code to <span className="text-slate-200 font-medium">{email}</span>.
            </p>

            {/* Test Helper box */}
            <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between">
              <div>
                <span className="text-[11px] text-slate-400 block">Simulated Code:</span>
                <span className="font-mono text-sm font-semibold text-indigo-400 tracking-wider">
                  {generatedDemoCode}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setCode(generatedDemoCode)}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-medium px-2 py-1 rounded bg-indigo-950/50 border border-indigo-900/50"
              >
                Auto-fill
              </button>
            </div>

            {error && (
              <div className="p-3 text-xs text-rose-300 bg-rose-950/40 border border-rose-900/50 rounded-lg">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="auth-code" className="block text-xs font-medium text-slate-300 mb-1.5">
                6-Digit Security Code
              </label>
              <input
                id="auth-code"
                type="text"
                maxLength={6}
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
                placeholder="123456"
                required
                className="w-full text-center tracking-[0.3em] font-mono text-base px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="submit"
                disabled={code.length !== 6}
                className="w-full py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors rounded-lg shadow-sm"
              >
                Verify & Continue
              </button>
            </div>
          </form>
        )}

        {step === 'new-password' && (
          <form onSubmit={handleSetNewPassword} className="space-y-4">
            <h3 className="text-base font-semibold text-white tracking-tight">Create New Password</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Your identity has been verified. Choose a strong, distinct password.
            </p>

            {error && (
              <div className="p-3 text-xs text-rose-300 bg-rose-950/40 border border-rose-900/50 rounded-lg">
                {error}
              </div>
            )}

            <div>
              <label htmlFor="new-pass" className="block text-xs font-medium text-slate-300 mb-1.5">
                New Password
              </label>
              <div className="relative">
                <input
                  id="new-pass"
                  type={showPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  className="w-full px-3 py-2 pr-10 text-sm bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 focus:outline-none"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <PasswordStrengthMeter password={newPassword} />
            </div>

            <div>
              <label htmlFor="confirm-pass" className="block text-xs font-medium text-slate-300 mb-1.5">
                Confirm New Password
              </label>
              <input
                id="confirm-pass"
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className="w-full px-3 py-2 text-sm bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors rounded-lg shadow-sm"
              >
                Save New Password
              </button>
            </div>
          </form>
        )}

        {step === 'success' && (
          <div className="space-y-4 text-center py-2">
            <div className="w-12 h-12 mx-auto rounded-full bg-emerald-950/60 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Password Updated</h3>
              <p className="text-xs text-slate-400 mt-1">
                Your credentials have been securely updated. You may now sign in with your new password.
              </p>
            </div>
            <button
              onClick={handleResetComplete}
              className="w-full py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 transition-colors rounded-lg"
            >
              Return to Sign In
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
