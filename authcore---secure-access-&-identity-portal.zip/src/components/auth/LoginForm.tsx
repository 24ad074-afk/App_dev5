import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Eye, EyeOff, Lock, Mail, ArrowRight, UserCheck } from 'lucide-react';
import alexAvatar from '../../assets/images/avatar_alex_tech_1791479380661.jpg';
import elenaAvatar from '../../assets/images/avatar_elena_design_1791479394832.jpg';

interface LoginFormProps {
  onSwitchToRegister: () => void;
  onOpenForgotPassword: (email: string) => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({ onSwitchToRegister, onOpenForgotPassword }) => {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!email.trim() || !password) {
      setErrorMessage('Please fill in both email and password.');
      return;
    }

    setIsLoading(true);
    // Simulate natural response latency <= 200ms
    setTimeout(() => {
      const res = login(email, password, rememberMe);
      setIsLoading(false);
      if (!res.success) {
        setErrorMessage(res.message || 'Authentication failed. Please check your credentials.');
      }
    }, 180);
  };

  const fillDemoAccount = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setErrorMessage(null);
  };

  return (
    <div className="w-full">
      {/* Header */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold tracking-tight text-white">Sign In to AuthCore</h2>
        <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">
          Access your enterprise identity portal, manage active sessions, and review security audits.
        </p>
      </div>

      {/* Demo Credentials Quick-Fill Cards */}
      <div className="mb-6 p-3 bg-slate-900/60 border border-slate-800/80 rounded-xl">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[11px] font-medium text-slate-400">Quick Test Profiles (1-Click Fill)</span>
          <span className="text-[10px] text-indigo-400 font-mono">password: password123!</span>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => fillDemoAccount('alex.morgan@worksuite.io', 'password123!')}
            className="flex items-center gap-2 p-2 rounded-lg bg-slate-950/80 hover:bg-slate-950 border border-slate-800 text-left transition-colors group"
          >
            <img
              src={alexAvatar}
              alt="Alex Morgan"
              className="w-7 h-7 rounded-md object-cover shrink-0"
              referrerPolicy="no-referrer"
            />
            <div className="min-w-0">
              <div className="text-xs font-semibold text-slate-200 group-hover:text-white truncate">
                Alex Morgan
              </div>
              <div className="text-[10px] text-slate-400 truncate">Engineering Lead</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => fillDemoAccount('elena.rostova@designflow.co', 'password123!')}
            className="flex items-center gap-2 p-2 rounded-lg bg-slate-950/80 hover:bg-slate-950 border border-slate-800 text-left transition-colors group"
          >
            <img
              src={elenaAvatar}
              alt="Elena Rostova"
              className="w-7 h-7 rounded-md object-cover shrink-0"
              referrerPolicy="no-referrer"
            />
            <div className="min-w-0">
              <div className="text-xs font-semibold text-slate-200 group-hover:text-white truncate">
                Elena Rostova
              </div>
              <div className="text-[10px] text-slate-400 truncate">Design Director</div>
            </div>
          </button>
        </div>
      </div>

      {/* Error message */}
      {errorMessage && (
        <div className="mb-4 p-3 rounded-lg bg-rose-950/40 border border-rose-900/60 text-xs text-rose-300">
          {errorMessage}
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Email */}
        <div>
          <label htmlFor="login-email" className="block text-xs font-medium text-slate-300 mb-1.5">
            Work Email Address
          </label>
          <div className="relative">
            <input
              id="login-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@company.com"
              required
              autoComplete="email"
              className="w-full pl-9 pr-3 py-2 text-sm bg-slate-900 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
            <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          </div>
        </div>

        {/* Password */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label htmlFor="login-password" className="text-xs font-medium text-slate-300">
              Password
            </label>
            <button
              type="button"
              onClick={() => onOpenForgotPassword(email)}
              className="text-xs text-indigo-400 hover:text-indigo-300 transition-colors"
            >
              Forgot password?
            </button>
          </div>
          <div className="relative">
            <input
              id="login-password"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              required
              autoComplete="current-password"
              className="w-full pl-9 pr-10 py-2 text-sm bg-slate-900 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
            <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 p-0.5 rounded transition-colors"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Remember me */}
        <div className="flex items-center justify-between pt-1">
          <label className="flex items-center gap-2 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={rememberMe}
              onChange={(e) => setRememberMe(e.target.checked)}
              className="w-4 h-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500 focus:ring-offset-slate-950 accent-indigo-600 cursor-pointer"
            />
            <span className="text-xs text-slate-400">Remember this browser session</span>
          </label>
        </div>

        {/* Submit */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 transition-colors rounded-lg shadow-sm mt-2"
        >
          {isLoading ? (
            <span>Authenticating...</span>
          ) : (
            <>
              <span>Sign In to Workspace</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      {/* Switch to Register */}
      <div className="mt-6 pt-5 border-t border-slate-800/80 text-center">
        <p className="text-xs text-slate-400">
          New to AuthCore?{' '}
          <button
            type="button"
            onClick={onSwitchToRegister}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 underline underline-offset-4 transition-colors"
          >
            Create an account
          </button>
        </p>
      </div>
    </div>
  );
};
