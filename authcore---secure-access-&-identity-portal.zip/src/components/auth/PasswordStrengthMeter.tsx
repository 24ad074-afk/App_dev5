import React from 'react';
import { calculatePasswordStrength } from '../../utils/authStorage';
import { Check, X } from 'lucide-react';

interface PasswordStrengthMeterProps {
  password: string;
}

export const PasswordStrengthMeter: React.FC<PasswordStrengthMeterProps> = ({ password }) => {
  if (!password) return null;

  const strength = calculatePasswordStrength(password);

  const getBarColor = () => {
    switch (strength.score) {
      case 1:
        return 'bg-rose-500';
      case 2:
        return 'bg-amber-500';
      case 3:
        return 'bg-blue-500';
      case 4:
        return 'bg-emerald-500';
      default:
        return 'bg-slate-700';
    }
  };

  const getLabelColor = () => {
    switch (strength.score) {
      case 1:
        return 'text-rose-400';
      case 2:
        return 'text-amber-400';
      case 3:
        return 'text-blue-400';
      case 4:
        return 'text-emerald-400';
      default:
        return 'text-slate-400';
    }
  };

  return (
    <div className="mt-2 space-y-2 text-xs">
      <div className="flex items-center justify-between text-slate-400">
        <span>Password strength:</span>
        <span className={`font-semibold ${getLabelColor()}`}>{strength.label}</span>
      </div>

      {/* Segmented bar */}
      <div className="grid grid-cols-4 gap-1.5 h-1.5 w-full">
        {[1, 2, 3, 4].map((step) => (
          <div
            key={step}
            className={`h-full rounded-sm transition-colors duration-200 ${
              strength.score >= step ? getBarColor() : 'bg-slate-800'
            }`}
          />
        ))}
      </div>

      {/* Requirement checklist */}
      <div className="grid grid-cols-2 gap-x-3 gap-y-1 pt-1 text-[11px] text-slate-400">
        <div className={`flex items-center gap-1.5 ${strength.hasMinLength ? 'text-emerald-400' : 'text-slate-500'}`}>
          {strength.hasMinLength ? <Check className="w-3 h-3 shrink-0" /> : <X className="w-3 h-3 shrink-0" />}
          <span>8+ characters</span>
        </div>
        <div className={`flex items-center gap-1.5 ${strength.hasUpper && strength.hasLower ? 'text-emerald-400' : 'text-slate-500'}`}>
          {strength.hasUpper && strength.hasLower ? <Check className="w-3 h-3 shrink-0" /> : <X className="w-3 h-3 shrink-0" />}
          <span>Upper & lowercase</span>
        </div>
        <div className={`flex items-center gap-1.5 ${strength.hasNumber ? 'text-emerald-400' : 'text-slate-500'}`}>
          {strength.hasNumber ? <Check className="w-3 h-3 shrink-0" /> : <X className="w-3 h-3 shrink-0" />}
          <span>At least 1 number</span>
        </div>
        <div className={`flex items-center gap-1.5 ${strength.hasSpecial ? 'text-emerald-400' : 'text-slate-500'}`}>
          {strength.hasSpecial ? <Check className="w-3 h-3 shrink-0" /> : <X className="w-3 h-3 shrink-0" />}
          <span>Special symbol</span>
        </div>
      </div>
    </div>
  );
};
