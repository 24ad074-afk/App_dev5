import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { ShieldCheck, X } from 'lucide-react';

export const TwoFactorModal: React.FC = () => {
  const { pending2FAUser, verify2FA, cancel2FA } = useAuth();
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  if (!pending2FAUser) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const res = verify2FA(code);
    if (!res.success) {
      setError(res.message || 'Verification failed');
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="two-factor-title"
    >
      <div className="relative w-full max-w-sm bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-6 text-slate-200">
        <button
          onClick={cancel2FA}
          className="absolute top-4 right-4 text-slate-500 hover:text-slate-300 p-1 rounded-md transition-colors"
          aria-label="Cancel verification"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-2.5 text-indigo-400 mb-2">
          <ShieldCheck className="w-5 h-5" />
          <h3 id="two-factor-title" className="text-base font-semibold text-white tracking-tight">
            Two-Factor Challenge
          </h3>
        </div>

        <p className="text-xs text-slate-400 leading-relaxed mb-4">
          Account <span className="text-slate-200 font-medium">{pending2FAUser.email}</span> requires a 6-digit authenticator code.
        </p>

        {/* Demo Helper */}
        <div className="p-3 mb-4 bg-slate-950 border border-slate-800 rounded-lg flex items-center justify-between">
          <div>
            <span className="text-[11px] text-slate-400 block">Demo Passcode:</span>
            <span className="font-mono text-sm font-semibold text-indigo-400 tracking-wider">
              123456
            </span>
          </div>
          <button
            type="button"
            onClick={() => setCode('123456')}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-medium px-2 py-1 rounded bg-indigo-950/50 border border-indigo-900/50"
          >
            Auto-fill
          </button>
        </div>

        {error && (
          <div className="p-3 mb-4 text-xs text-rose-300 bg-rose-950/40 border border-rose-900/50 rounded-lg">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="totp-code" className="block text-xs font-medium text-slate-300 mb-1.5">
              Authenticator Token
            </label>
            <input
              id="totp-code"
              type="text"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
              placeholder="000000"
              autoFocus
              required
              className="w-full text-center tracking-[0.3em] font-mono text-base px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-100 placeholder-slate-600 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors"
            />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={cancel2FA}
              className="w-1/2 py-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition-colors rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={code.length !== 6}
              className="w-1/2 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors rounded-lg shadow-sm"
            >
              Confirm
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
