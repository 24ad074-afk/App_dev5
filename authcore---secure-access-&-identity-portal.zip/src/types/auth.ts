export interface UserSession {
  id: string;
  device: string;
  browser: string;
  location: string;
  ip: string;
  isCurrent: boolean;
  lastActive: string;
}

export interface AuditLogEntry {
  id: string;
  event: string;
  timestamp: string;
  device: string;
  ip: string;
  status: 'success' | 'warning' | 'info';
}

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: string;
  department: string;
  avatarUrl: string;
  bio: string;
  location: string;
  joinedAt: string;
  lastLoginAt: string;
  twoFactorEnabled: boolean;
  rememberMe?: boolean;
  emailNotifications: boolean;
  sessions: UserSession[];
  activityLog: AuditLogEntry[];
}

export type AuthMode = 'login' | 'register' | 'forgot-password' | 'verify-2fa';
export type DashboardTab = 'overview' | 'profile' | 'security' | 'sessions' | 'directory';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  description?: string;
}
